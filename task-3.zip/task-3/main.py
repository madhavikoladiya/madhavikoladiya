def get_user_info():
    name = input("Enter your name: ")
    age = int(input("Enter your age: "))
    is_student = input("Are you a student? (yes/no): ").lower() == 'yes'
    
    return name, age, is_student

def process_user_info(name, age, is_student):
    # Check if the user is a student and adjust the response accordingly
    student_status = "a student" if is_student else "not a student"

    # Provide a personalized response
    if age < 18:
        response = f"Hi {name}, you are {student_status} and a minor."
    elif age >= 18 and age < 21:
        response = f"Hi {name}, you are {student_status} and an adult but not allowed to drink."
    else:
        response = f"Hi {name}, you are {student_status} and a legal adult."

    return response

def main():
    print("Welcome to the Interactive User Information Program!")

    # Get user information
    user_name, user_age, user_is_student = get_user_info()

    # Process user information
    result = process_user_info(user_name, user_age, user_is_student)

    # Display the result
    print("\nResult:")
    print(result)

if __name__ == "__main__":
    main()
