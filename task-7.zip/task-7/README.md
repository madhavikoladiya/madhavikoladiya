# Django AJAX CRUD Tutorial with Example – CRUD

Find this Tutorial 

Part 1 - https://studygyaan.com/django/django-ajax-crud-tutorial-with-example-part-1-create-and-read

Part 2 - https://studygyaan.com/django/django-ajax-crud-tutorial-with-example-part-2-update-and-delete
