# MyApp/views.py
from django.shortcuts import render
from .models import Greeting

def hello_django(request):
    greeting = Greeting.objects.first()
    return render(request, 'hello_django.html', {'greeting': greeting})
